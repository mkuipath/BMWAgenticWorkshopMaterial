# PawsitiveVet — PharmaDisp (desktop pharmacy app)

PharmaDisp is the mock **desktop** pharmacy dispensing app for the course. It is the target of the
**DraftRx** desktop RPA (Module 4): the automation opens PharmaDisp, searches the patient, and drafts
a prescription through the WinForms wizard.

## Run it (Windows)
1. Unzip this folder anywhere.
2. Run **`publish/PharmaDisp.exe`**. It is self-contained — you do **not** need .NET installed.
3. Log in with your **sandbox pharmacist** credentials (the `pharm-…` username + password shown when
   you start a 24-hour sandbox in VetChart at https://pawsitivevet-vetchart.azurewebsites.net).

## Notes
- Keep the whole `publish/` folder together — the `.exe` needs the DLLs beside it (it will not run
  from a single copied file).
- PharmaDisp has no API; it is driven purely through its UI, which is the point of the desktop-RPA
  module. Capture its controls with the Studio Object Repository as the module describes.
- It is clinic-scoped for sandbox logins, so you only see your own sandbox’s patients.
