# Process Design Document (PDD)

## PawsitiveVet Lab Results Processing & Prescription Fulfillment

> This document describes each step's **nature** and each system's **integration surface**,
> so a Solution Design Document generated from it lands on the *right tool per step*
> (RPA / agent / API workflow / coded app / orchestration). `[SME REVIEW]` marks items a
> subject-matter expert should confirm.

---

## 1. Process Overview

### 1.1 Organization Background
PawsitiveVet is an 8-clinic veterinary group. External labs return diagnostic results as
PDFs; each must be recorded in the medical record, evaluated for abnormal findings, and —
when clinically indicated — turned into a prescription that a veterinarian approves before
dispensing.

### 1.2 Process Summary
Each inbound lab report is handled as a durable, governed process that (a) receives and
**triages** the report, (b) **records** the results in VetChart, (c) **evaluates** the
findings and produces a reviewable **recommendation + rationale**, (d) **drafts** a
prescription in PharmaDisp when indicated, (e) presents a **decision surface** to the
veterinarian, (f) **syncs** the decision to the medical record, (g) **notifies** the owner,
and (h) is **observable and recoverable** at volume. A human always controls the clinical
decision.

### 1.3 End-to-End Process Flow
Receive & triage report → record lab results (VetChart) → evaluate & recommend →
[if indicated] draft prescription (PharmaDisp) → **veterinarian reviews & decides** →
sync decision to the medical record → notify owner → monitor/operate.

### 1.4 Process Participants
Reference lab (produces reports) · Vet Tech (oversees intake/records) · **Veterinarian**
(sole clinical decision-maker) · Pharmacy Tech (dispenses after approval) · Pet Owner
(notified) · Automation/Ops team (operates the process, handles exceptions).

---

## 2. Scope

### 2.1 In Scope
Intake & triage of inbound reports; lab-result recording; clinical evaluation and
recommendation with written rationale; prescription drafting; the veterinarian's review &
decision; write-back to the medical record; owner notification; operational monitoring and
exception handling — all orchestrated as one durable process, built end-to-end by coding
agents via the `uip` CLI + UiPath skills.

### 2.2 Out of Scope
Actual dispensing/inventory changes; billing; any autonomous clinical decision; modifying
the external systems themselves (VetChart/PharmaDisp are integrated with, not changed).

### 2.3 Automation & Human Boundary
The automation may record data, reason, recommend, and draft — but a **prescription only
becomes active after a veterinarian approves it.** The automation never overrides a hard
safety gate (see §3.3).

---

## 3. Clinical Authority Model

### 3.1 Principle
**The automation proposes; the veterinarian disposes.** Reasoning does not move the clinical
decision to software — it makes the recommendation *better explained* for the human.

### 3.2 Authority Matrix
| Action | Automation may… | Human required? |
|--------|------------------|-----------------|
| Record lab results | Do it | No |
| Evaluate & recommend | Do it (with rationale + confidence) | No |
| Draft a prescription | Draft as "Pending Vet Approval" | No |
| **Approve a prescription** | **Never** | **Yes (vet)** |
| Cancel on a hard safety gate | Must (automatic) | No |

### 3.3 Safety Gates (deterministic, non-overridable)
These are **computed deterministically**, never left to model judgment, and **cannot be
overridden**:
- **Critical drug interaction** → cancel the prescription, route to vet.
- **No species-approved medication** → no prescription; flag for vet review.
- **Physiologically implausible value** → record, flag suspected lab error, no prescription.
- **Inactive/deceased patient** → stop; no record or prescription.

### 3.4 What the Automation Never Does
Approve a prescription · override a safety gate · invent a dosage or a reference range ·
proceed past a stop condition · hide an exception.

---

## 4. Systems & Integration Surfaces
*(This section exists so the SDD can choose API-first vs. RPA per system.)*

### 4.1 VetChart (Web EMR) — UI **and** REST API
- Web UI (browser) — used for **lab-result entry** (rich form).
- **REST API** — used for **reads, verification, and decision sync**:
  `GET /api/patients/search`, `GET /api/patients/:id`, `GET /api/patients/:id/lab-results`,
  `POST /api/patients/:id/lab-results`, `GET/POST /api/patients/:id/prescriptions`,
  `PATCH /api/prescriptions/:id` (approve/reject), `GET /api/approval-queue`,
  `GET /api/dashboard`. Azure SQL backend, **shared with PharmaDisp**.

### 4.2 PharmaDisp (Desktop Pharmacy) — UI only, **no API**
.NET WinForms; formulary, interaction, and dosage data in its DB but **no public API** →
all interaction is via **desktop UI automation**.

### 4.3 Intake Source — Orchestrator **Storage Bucket** + document extraction (IXP)
Inbound reports (a mixed batch: real lab PDFs + occasional junk/malformed/duplicate) land in
a `LabReports` bucket. A new file starts one process instance (manual while building;
auto-trigger in operations). Each PDF's structured fields (patient/report IDs, test type,
test values) are read by **IXP document extraction** run inline, and that raw output is then
**verified by the intake agent** before it enters the process — extraction and judgment are
kept separate (see S1).

### 4.4 Human Task Surface — **Action Center**
The veterinarian's decision is a human task rendered by a purpose-built app; the process
suspends until the vet acts.

### 4.5 Notification Channel — Integration Service email connector (gated/optional)
Owner outcome notification. Recipient is configurable (defaults to the operator's own
address in non-production).

### 4.6 Credentials & Clinics
VetChart user `vtech1`, PharmaDisp user `ptech1`, password `pawsitive123`, primary clinic
PV-DT. Eight clinics: PV-DT/WS/NP/RL/SH/LK/MV/HB (plus PV-EP introduced in the capstone
scenario). Full credential and clinic tables are defined in the solution's reference data.

---

## 5. Process Steps (with step nature → skill signal)

> Each step notes its **nature**, which signals the implementing skill. The SDD makes the
> final mapping.

| # | Step | What happens | Step nature (→ signal) |
|---|------|--------------|------------------------|
| S1 | **Intake: extract & validate** | Extract the report's structured fields from the PDF (patient/report IDs, test type, test values); then **verify that extraction** — resolve low-confidence fields, decide if it's a valid lab report, dedupe, confirm the patient exists, reject junk/malformed | **Document extraction → IXP node**, then **verification + triage judgment → agent** (+ a data-lookup tool) |
| S2 | **Record lab results** | Enter the panel + values into the patient's VetChart record | Rich UI, form entry → **RPA (web)** |
| S3 | **Evaluate & recommend** | Compare values to species ranges; choose medication or "none"; compute dosage; check interactions; produce rationale + confidence; decide escalate | **Judgment → agent**, with **deterministic tools** for ranges/dosage/interactions |
| S4 | **Draft prescription** | Drive the PharmaDisp wizard to draft as "Pending Vet Approval" | Desktop UI, no API → **RPA (desktop)** |
| S5 | **Vet review & decision** | Vet sees the recommendation + rationale + warnings and Approves/Modifies/Rejects | Human decision needing rich context → **coded action app + HITL** |
| S6 | **Sync decision** | Write the vet's decision to the medical record | Data write to an existing API → **API workflow** (`PATCH /api/prescriptions/:id`) |
| S7 | **Notify owner** | Email the outcome | System integration → **connector** (gated) |
| S8 | **Monitor & operate** | Track instances, exceptions, throughput, approvals | Observability → **application dashboards + orchestration traces** |
| — | **Orchestration** | Sequence S1–S8 durably, per report, with routing/retries/waits | Long-running, multi-actor, resumable → **Maestro (instance per report)** |

Detailed step logic (field-level entry, wizard steps, verification) is specified per node in
the SDD.

---

## 6. Business Rules
The clinical reference data (per-species reference ranges, medication formulary, dosage
rules, and the drug-interaction matrix) is maintained as the solution's **reference data**
and exposed to the automation as deterministic tools. The rules that use it:
- **6.1 Reference ranges by species** — per-analyte Normal/High/Low/Critical thresholds by
  species (Canine, Feline, Avian, etc.). *Deterministic; exposed to the agent as a tool.*
- **6.2 Clinical rules** — lab-finding → medication mapping (e.g., elevated renal values →
  Benazepril). *The agent selects using this; it does not invent mappings.*
- **6.3 Dosage** — `dose_mg = weight_kg × dose_per_kg`, rounded **up** to the next available
  tablet strength. **Deterministic tool — never model-computed.**
- **6.4 Interaction severity** — Critical (cancel) / High (override w/ priority review) /
  Moderate (override w/ warning) / Low (informational). **Deterministic; Critical is a hard
  gate.**
- **6.5 Priority** — High if any Critical flag or WBC > 30; Normal otherwise. Drives Maestro
  **instance priority**.
- **6.6 Panels** — Blood Panel, Thyroid Panel, Urinalysis (+ Reptile Metabolic Panel added
  in the capstone scenario).

---

## 7. Exception Handling
Exceptions are handled as **process outcomes**:
- **Intake rejects** (not a lab report, unreadable, duplicate) → logged; routed to the
  operations exception queue in the decision app; instance stops.
- **Business exceptions** (patient not found, missing ID, deceased, species-not-approved,
  implausible value) → instance marked *Failed — Business Exception*; no retry; audit row.
- **Application exceptions** (UI/agent/transient failures) → *Failed — Application
  Exception*; auto-retry up to the configured maximum; then audit.
- **Recoverable** (medication out of stock → alternative) → continue with a documented
  substitution.
Every case is traceable in the instance list **and** the audit error report; nothing
disappears silently.

---

## 8. Data Definitions
- **`LabCase`** (the object flowing between nodes): `ReportId, ReportDate, ClinicId,
  PatientId, PetName, Species, Breed, TestType, TestValues, Priority, Recommendation,
  Rationale, Confidence, Escalate, VetChartRxId, Decision, DecisionNotes, Status`.
- `TestValues` = array of `{TestName, ResultValue, RefRangeLow, RefRangeHigh, Unit, Flag}`.
- Identifier formats (`PLR-YYYY-NNNNN`, `PV-NNNNN`), prescription statuses (Pending Vet
  Approval / Active / Rejected), and flag values (Normal/H/L/C) are defined in the solution's
  reference data.

---

## 9. Volume & Operating Model
- **Operating model:** one **Maestro instance per report**. Instance **priority** from §6.5.
  Durable state, built-in retries, per-instance traces.
- **Monitoring:** the VetChart & PharmaDisp application dashboards (pending approvals,
  drafts, labs, stock) plus the Maestro instance list/traces.
- **Volume target:** hundreds of reports/day processed as concurrent instances.

---

## 10. Roles & Responsibilities (RACI)
| Activity | Automation | Vet Tech | Veterinarian | Ops |
|----------|-----------|----------|--------------|-----|
| Intake/triage | R | A | — | C |
| Record results | R | A | I | — |
| Evaluate/recommend | R | C | I | — |
| Draft Rx | R | — | I | — |
| **Approve Rx** | — | — | **R/A** | — |
| Sync/notify | R | — | I | C |
| Operate/exceptions | R | C | I | A |

---

## 11. Solution Approach / Target Architecture
*(Business-to-platform bridge — direction, not a full design.)*

- **Orchestration:** a **Maestro flow** (`LabResultToScript`), one durable **instance per
  report**, is the process spine; each step above is a node.
- **Component/skill mapping** (from §5): PDF extraction = **IXP document-extraction node**;
  intake-validation + clinical evaluation = **low-code agents**; deterministic
  ranges/dosage/interactions + VetChart verify/sync = **API workflows**; VetChart entry +
  all PharmaDisp = **RPA**; vet decision = **coded Action App + Action Center (HITL)**;
  owner notification = **Integration Service connector** (gated).
- **Extract-then-verify:** IXP produces the raw structured fields; the intake agent verifies
  and cleans them (low-confidence resolution, dedupe, patient existence) before anything
  downstream trusts the data — the right tool for extraction, an agent for judgment.
- **Human-in-the-loop:** the vet decision is a suspending human task; the app is a thin
  decision surface (payload in, decision out); the flow syncs the decision back to VetChart.
- **Governance & safety:** deterministic safety gates (§3.3) sit outside model judgment; the
  agent interprets/decides/explains within guardrails; every prescription remains Pending
  until a vet approves.
- **Build constraint:** the entire solution is authored and deployed by **coding agents**
  using the `uip` CLI + UiPath skills, and shipped as one **Solution (`.uipx`)**.
- **Canonical component names** (use these exact names for the projects/nodes so the design
  stays consistent across regenerations):
  - Maestro Flow: **`LabResultToScript`**
  - Agents (low-code): **`LabProcessing_IntakeAgent`**, **`LabProcessing_ClinicalAgent`**
  - RPA: **`LabProcessing_RecordResults`** (VetChart web), **`LabProcessing_DraftRx`** (PharmaDisp desktop)
  - Coded Action App: **`LabProcessing_VetReviewApp`**
  - API Workflows: **`LabProcessing_ClinicalTools`** (the agents' deterministic tools: reference
    ranges, dosage, interactions, patient lookup) and **`LabProcessing_SyncDecision`** (`PATCH` to VetChart)
  - Document extraction: an **inline IXP node** in the Flow (`extract_report`) — not a separate project
  - Flow nodes: `extract_report` → `intake_validate` → `record_results` → `evaluate_recommend`
    → `check_recommendation` (gateway) → `draft_prescription` → `vet_review` (HITL) → `sync_decision` → `notify_owner`

---

## Appendix
- **Clinical reference data:** per-species reference ranges, the medication formulary, dosage
  rules, and the drug-interaction matrix (the solution's reference data, exposed as tools).
- **Walkthrough example:** Bella / PV-10234 / PLR-2025-00006.
- **Exception scenario test cases:** PLR-2025-00011..00020.
