# UiPath Coding Agents — Extended · Learner Resources

These are the files you need from us to build the **PawsitiveVet Lab Processing** solution as you
work through the course (the lessons themselves are in the online course). You build the solution
by prompting a coding agent that drives the `uip` CLI and the 12 UiPath skills — these resources
are the inputs, the mock apps, and the design reference you build *against*.

## Before you start — prerequisites
- **UiPath `uip` CLI** — two builds are used; see `contracts/ENVIRONMENT-CONTRACT.md` §1 (which one
  for which command). Pin a stable version.
- **Studio Desktop (STS)** with UiAutomation 26.4.1+ (for the RPA / Object-Repository capture).
- **VS Code** + the **UiPath Maestro** extension, signed in to Automation Cloud.
- **Node.js 18+**, **git**.
- The **12 course skills** are provided by your coding-agent harness — you do not install them by
  hand (`uip skills list` is not the source of truth if it errors).

## The two mock apps
- **VetChart (web EMR)** — hosted, no download: **https://pawsitivevet-vetchart.azurewebsites.net**
  Click **“Start a 24-hour sandbox”** on the login page to mint your own private clinic, logins,
  and a starter pack of lab-report PDFs. Inside the sandbox, **Admin → Sandbox — Learner Tools**
  lets you **add patients** and build **any lab-report PDF** (Lab PDF Studio: pick a patient + panel,
  set the values, generate) — so you can self-provision scenarios (including the reptile capstone)
  without waiting on anyone. Everything in a sandbox auto-deletes after 24 hours.
- **PharmaDisp (desktop pharmacy app)** — **separate download**, for Windows or macOS.
  Windows: `pawsitivevet-pharmadisp-windows.zip`, self-contained (no .NET install). macOS: the Apple Silicon or Intel `.tar.gz` build; follow the **PharmaDisp macOS setup guide** in the course for first-launch steps. Used from Module 4 (the DraftRx desktop RPA).

## What’s in this bundle
| Folder | What it is | Used in |
|---|---|---|
| `input-files/lab-results/` | 64 sample lab-report PDFs (incl. `PLR-2025-00006.pdf`, the renal/Carprofen demo, plus decoys). Your flow inputs. | Modules 2–12 |
| `design-reference/pdd.md` | The Process Design Document the whole solution is derived from. | Module 1 |
| `design-reference/*-sdd.md` | The **golden** Solution + per-project SDD set — the source of truth for names, contracts, and decisions. Compare your generated SDDs against these. | Module 1 onward |
| `contracts/ENVIRONMENT-CONTRACT.md` | Read once, applies to every module: which `uip` CLI, where assets live, how to verify login. | All |
| `contracts/DATA-CONTRACT.md` | The `LabCase` data contract (field names + casing) that flows between nodes. | Modules 1, 3, 5 |
| `contracts/DESIGN-STANDARD.md` | The design standard for the coded Action App (HITL). | Module 6 |
| `contracts/coded-app-theme.css` | Starter theme (Apollo-based tokens) for the coded app. | Module 6 |

## Generating more inputs
You usually don’t need to — use the **Lab PDF Studio** in your VetChart sandbox (Admin) to mint
fresh, unique-report-ID PDFs for any patient/panel on demand. The static PDFs in `input-files/` are
there as a known-good baseline and for offline reference.

## A note on report IDs
Each run consumes a report ID (the IntakeAgent rejects a duplicate — that’s the agent working). If
you re-run, mint a fresh PDF from the Lab PDF Studio so the ID is unique.
