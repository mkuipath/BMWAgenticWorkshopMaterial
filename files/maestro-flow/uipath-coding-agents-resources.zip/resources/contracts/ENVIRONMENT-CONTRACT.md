# Environment Contract — read once, applies to every module

> **Every module's build prompts assume this contract.** Load it before Step 1 of any module (or paste the 6-line "Quick card" below into your first prompt to the coding agent). It pins the three things the dry-run rediscovered in almost every module: which `uip` CLI to use, where the assets actually live, and how to verify you're logged in.

## Quick card (paste into the agent at the start of a module)

```
Environment: Windows. TWO uip CLIs exist — use the right one:
  • Studio-BUNDLED uip  → anything touching Studio IPC: `uip rpa …`, `uip maestro …`, `uip solution pack`.
    Path: "C:\Program Files\UiPathPlatform\Studio\<version>\cli\node_modules\.bin\uip"
  • GLOBAL uip (npm)     → `uip or …`, `uip ixp …`, `uip agent …`, package upload / process create.
Course assets live in ../rpa-deep-dive-course/ (input-files/lab-results/, apps/), NOT this folder.
Verify login with `uip login status` (never run bare `uip login` — it clobbers a valid session).
```

## 1. Two `uip` CLIs — which to use when

There are two `uip` binaries and they are **not interchangeable**:

| Use the… | For | Why |
|---|---|---|
| **Studio-bundled** `uip` at `C:\Program Files\UiPathPlatform\Studio\<ver>\cli\node_modules\.bin\uip` | `uip rpa …`, `uip maestro flow …`, `uip solution pack` — anything that starts Studio's Helm/IPC | The npm-global build ships an **incomplete Helm** (missing DLLs) → `flow debug`/`rpa` crash with `0x33`. The bundled one has the complete runtime. |
| **Global** `uip` (`npm i -g @uipath/cli`, on `PATH`) | `uip or …` (assets/machines/jobs/packages/processes), `uip ixp …`, `uip agent …`, `uip docsai …` | These tools install only to a **user-writable** path; the bundled `uip` can't install them (`EPERM` under Program Files). |

**Pin a known-good version.** The public npm `latest` is a dev build with the broken Helm; `1.197.1` doesn't exist publicly. Standardise on the **bundled** `uip` for Studio work and pin the global to a version your tenant confirms.

**Broken CLI verbs to avoid** (use the workaround):
- **Starting the LabResultToScript flow (a Maestro flow with a `file` input) — use the portal.** No single CLI verb both allocates a runtime AND maps the PDF to the `reportFileRef` input: `uip maestro flow process run "<pkg>:<ver>" <folderKey> --release-key <key> --attachment reportFileRef=<pdf>` maps the file but does **not** allocate a runtime → the job hangs in "Running"; `uip or jobs start <processGUID> --strategy ModernJobsCount --attachment reportFileRef=<pdf>` allocates but does **not** map the file input (missing mappings). The **Orchestrator portal Jobs → Start** (StartJobs semantics) is the proven-green start. Programmatic/CLI auto-start remains portal-driven for now — no single CLI verb both allocates a runtime and maps the PDF input, so use the Orchestrator portal's Jobs → Start until that gap closes.
- Also note a flow instance runs under the identity that **starts** it, and its RPA sub-jobs only get a host if that identity owns a connected unattended runtime in the folder — start from the VM/portal, not a personal dev CLI.
- `uip agent publish --direct` → "No .uipx in temp/input". Use `uip solution pack` → `uip or packages upload` → `uip or processes update-version`.
- `uip agent tool add` for Api tools → "Release not found". Hand-author `resources/<tool>/resource.json`.
- **Hand-authored `Api` `project.json` is not deployable** → `uip or packages upload` returns **HTTP 500** when an entry-point `uniqueId` isn't a GUID. Scaffold Api workflows via `uip api-workflow init` (real `project.uiproj` + GUID uniqueIds).

## macOS

There is no Studio-bundled `uip` on macOS, because Studio Desktop is Windows-only. Use the global
`uip` for everything, including `uip rpa`. `uip rpa` launches a native macOS Studio host
(`@uipath/studio-helm-darwin-arm64`, resolved automatically) that needs the **.NET 8 runtime**
installed separately — without it `uip rpa` hangs with no error. Everything else in this contract
(asset locations, `uip login status`, the portal-driven Flow start) is identical on macOS. See the
PharmaDisp macOS setup guide for the four one-time prerequisites.

## 2. Where the assets live

Bare relative paths in older module drafts resolve to the wrong folder. Absolute-from-repo:

| Asset | Path |
|---|---|
| Sample lab PDFs | `rpa-deep-dive-course/input-files/lab-results/` |
| Mock app source (VetChart, PharmaDisp, seed-generator) | `rpa-deep-dive-course/apps/` |
| **PDF mint tool** (generate fresh unique-ID inputs) | `rpa-deep-dive-course/apps/seed-generator/mint_lab_pdf.py` |
| Golden SDD set | repo root (`*-sdd.md`) / `01-blueprint-output/` |
| Design standard + theme for the coded app | `resources/contracts/DESIGN-STANDARD.md`, `resources/contracts/coded-app-theme.css` |

## 3. Verify state without breaking it

- Login: `uip login status` (shows org/tenant/expiry). Do **not** run bare `uip login` mid-session — it opens a browser flow and can clobber a valid token. Switch tenants with `uip login tenant set <tenant>`. (`uip auth status` does not exist.)
- "Is a skill installed?" — the harness pre-installs the 12 course skills; `uip skills list` is **not** the source of truth if it errors.

## 4. Verification legend (used across modules)

Each build/validate step is tagged with where it runs and how you check it:

- 🖥️ **CLI-checkable** — a `uip …` command proves it.
- 🎛️ **Studio Desktop GUI** — needs the Studio Properties panel / designer (e.g. UIAutomation input mode, OR capture).
- 🌐 **Orchestrator / Portal UI** — a browser action in Automation Cloud (e.g. IXP "deploy To folder", starting a Maestro run, Action Center).
- 👤 **Manual / human** — a human judgement or an app-login you do by hand.
