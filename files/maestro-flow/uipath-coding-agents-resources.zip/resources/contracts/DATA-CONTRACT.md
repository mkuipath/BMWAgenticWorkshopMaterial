# Data Contract Card — the `LabCase` shape, pinned once

> \*\*Why this exists:\*\* every seam that most often breaks in this build — the RPA `NullReferenceException`, the vet-review app's all-null lab table, the empty IntakeAgent input — traces to there being no single source of truth for the case shape. This card is that source. \*\*Every node/app that reads the case must match this casing exactly.\*\* Module 2 Step 3 establishes it; Modules 4, 5, 6 each validate their reads against it.

## The one gotcha that caused two separate bugs

> `labCase` \*\*scalar\*\* fields are \*\*PascalCase\*\*. `labCase.TestValues` \*\*array items\*\* are \*\*camelCase\*\*.

That single asymmetry causes two separate bugs: RecordResults reading `currentTest("TestName")` → NullRef, and the vet app reading `t.TestName` → every lab row null. Read the table below and you avoid both.

## `LabCase` — the object threaded through the flow

|Field|Casing|Type|Source|Consumers|
|-|-|-|-|-|
|`ReportId`|Pascal|string|IXP `extract\_report` → normalize|intake, record\_results, vet\_review, dedup gate|
|`ReportDate`|Pascal|string (`YYYY-MM-DD`)|IXP → normalize|record\_results (⚠ reformat to `MM/DD/YYYY` before typing)|
|`ClinicId`|Pascal|string (`PV-DT`)|IXP → normalize|record\_results, draft\_prescription, vet\_review|
|`PatientId`|Pascal|string (`PV-NNNNN`)|IXP → normalize|ALL|
|`PetName` / `Species` / `Breed`|Pascal|string|IXP → normalize|vet\_review, draft\_prescription|
|`TestType`|Pascal|string (`Blood Panel`)|IXP → normalize|record\_results, agents|
|**`TestValues`**|Pascal (the array)|array|IXP → normalize|record\_results, agents, vet\_review|
|↳ item `testName`|**camel**|string|normalize|record\_results (`currentTest("testName")`), vet\_review (`t.testName`)|
|↳ item `resultValue`|**camel**|string|normalize|same|
|↳ item `refRangeLow` / `refRangeHigh`|**camel**|string|normalize|same|
|↳ item `unit`|**camel**|string|normalize|same|
|↳ item `flag`|**camel**|string (`H`/`L`/`C`/``)|normalize|record\_results (map to display text), vet\_review|
|`weight\_kg`|snake|number|**VetChart `search\_patient`**, NOT IXP|ClinicalAgent (REQUIRES it), draft\_prescription|
|`existingMedications`|camel|string\[]|**VetChart `search\_patient`**, NOT IXP|ClinicalAgent (interaction check)|
|`Status`|Pascal|enum|IntakeAgent|check\_intake\_result gateway|

**Enrichment note:** `weight\_kg`, `age`, and `existingMedications` are **not in the lab PDF** — IXP cannot produce them. The IntakeAgent's `search\_patient` tool reads them from the VetChart patient master and enriches the `LabCase`. The low-code agents do **not** read Orchestrator assets directly; VetChart URL/creds live in `LabProcessing\_ClinicalTools`, and the agents inherit access via the tool.

## Agent output enums — pin them, don't free-text

The ClinicalAgent expressed frequency nondeterministically ("SID" one run, "q24h" the next) and broke the PharmaDisp dropdown. **Constrain the agent's output schema** to fixed enums so downstream RPA never has to guess:

* `medication.frequency` ∈ { `Once daily`, `Twice daily`, `Three times daily`, `Every 8 hours`, `Every 12 hours`, `Every other day`, `As needed` } (the exact PharmaDisp dropdown values).
* `medication.tabletStrength` — a bare number + unit the PharmaDisp list contains.
* Keep a **defensive normalizer** in the RPA (`SID`/`q24h`/`QD`→`Once daily`, etc.) as a backstop, and an **eval assertion** that `frequency` ∈ the known set.

## IXP runtime shape — don't trust the declared schema

The IXP node's **runtime** output matches **neither** its declared (flat `Fields\[]`) schema **nor** the raw DU-framework API. At runtime it's the classic DU nested layout: `ExtractionResult.ResultsDocument.Fields\[]` where each label group is `FieldType:"FieldGroup"`, leaves live in `Values\[occurrence].Components\[]` (`leaf.Values\[0].Value`), and repeatable groups have one `Values` entry per row. `normalize\_extraction` must walk FieldGroups recursively (with a Tables\[] fallback) and JSON.parse any layer that arrives stringified. Module 3 walks through the reference parser.

