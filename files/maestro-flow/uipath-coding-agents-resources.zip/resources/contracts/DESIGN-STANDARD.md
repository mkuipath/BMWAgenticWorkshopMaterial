# Coded App Design Standard (UiPath Apollo)

The course's Coded Apps (Action Apps + Web Apps) share one visual standard so
every learner's app looks professional by default instead of hand-rolled. It is
built on the **UiPath Apollo design system** (`@uipath/apollo-core`) and ships as
a single drop-in stylesheet: [`coded-app-theme.css`](./coded-app-theme.css).

> **Why this exists:** the `uipath-coded-apps` skill ships **no** design guidance,
> and the SDD's "UiPath design system via `@uipath/uipath-typescript`" is wrong —
> that SDK is platform services (Entities/Tasks), not UI. Apollo is the real
> design system, and its tokens are on public npm. (See BUILD-LOG **F38**.)

---

## 1. Setup (once per app)

```bash
# Apollo tokens — install from the PUBLIC registry (the course .npmrc scopes
# @uipath to a private feed, which 401s without the flag).
npm install @uipath/apollo-core --@uipath:registry=https://registry.npmjs.org
```

1. Copy `coded-app-theme.css` → `src/theme.css`.
2. Import it **first**, before app styles, in `src/main.tsx`:
   ```ts
   import './theme.css';
   import './styles.css'; // your app layout, which may @import "./theme.css"
   ```
3. Put a theme class on `<body>` so Apollo tokens resolve. In `index.html`:
   ```html
   <body class="apollo-design light">
   ```
   and keep it in sync at runtime (Action Center passes the current theme):
   ```ts
   document.body.className = `apollo-design ${isDark ? 'dark' : 'light'}`;
   ```
4. `vite.config.ts` must set `base: './'` (platform handles routing).

Result: authentic Apollo colours/typography/spacing, automatic light/dark, ~13 kB
gzipped of tokens. Apollo web fonts are **not** bundled (they're CJK-heavy /
multi-MB); the token font-stacks fall back to system fonts. To ship real fonts:
`@import "@uipath/apollo-core/fonts/font.css";`.

---

## 2. Two gotchas (each cost real debugging time)

| # | Gotcha | Fix |
|---|---|---|
| **G1** | **Import path.** `@import "@uipath/apollo-core/dist/tokens/css/theme-variables.css"` **fails the build** — the package `exports` map is `./tokens/* → ./dist/tokens/*`, and the `dist/…` path is blocked. | Import **`@uipath/apollo-core/tokens/css/theme-variables.css`** (drop `dist`). |
| **G2** | **Bare `--color-primary` does NOT resolve** in this Apollo build — anything with `background: var(--color-primary)` renders **transparent** (classic symptom: a button that's invisible until you hover, because `:hover` uses `--color-primary-hover`, which *does* resolve). | Anchor the brand to a semantic token + hex fallback: `--brand: var(--color-foreground-link, #0067df)`. Only `--color-primary-hover/-pressed` and the semantic tokens (`--color-foreground-link`, `--color-selection-indicator`, `--color-background-selected`) are reliable. (BUILD-LOG **F40**.) |

---

## 3. What the standard gives you

**Design tokens** (aliased onto Apollo, with hex fallbacks): `--brand`,
`--brand-strong/-soft`, `--accent`, `--page`, `--surface`, `--surface-2`,
`--border`, `--border-strong`, `--text`/`-2`/`-3`, semantic `--ok/--warn/
--danger/--info` (+ `-bg`), `--font`/`--font-heading`, a type scale (`--fs-*`),
spacing (`--sp-1…8`), radii (`--radius*`), `--shadow-sm/-md`, `--ring`.

**Primitive classes:** `.card`, `.section-title`, `.badge` (+ `-ok/-warn/
-danger/-info/-neutral`), `.chip`, `.btn` + `.btn-primary`, `.muted`,
`.computed-tag`, `.sr-only`, `.table-scroll`.

Build your app layout in a second `styles.css` that `@import`s the theme and uses
these tokens/primitives. Never hardcode colours/spacing — use the tokens.

---

## 4. Reusable UX patterns (from the Prescription Review app)

These are worth teaching and reusing in any review/approval surface:

- **Sticky action rail.** Two-pane grid (`minmax(0,1fr) 400px`); the decision
  panel is a `position: sticky` right rail so the action is always in view.
  Collapses to one column under ~1040px.
- **Highlight the decision drivers.** Pull the "why" out of prose into scannable
  chips/labels: assessment/diagnosis chip, a computed **dosing-basis** formula
  (`0.5 mg/kg × 31.2 kg` in a `<code>`), **key-findings** chips, and emphasise the
  one value the decision hinges on (here, **weight**).
- **Reference-range gauge.** For any value-vs-range, render a track with a green
  "normal band" (`24%–76%`) and a needle marker that sits **outside** the band
  when out of range (amber/red). Far more legible than raw numbers. Note: use a
  **white** track on tinted (abnormal) rows — a grey track disappears on beige.
- **Flag/severity colour.** `Normal`→green, `H/L`→amber, `C`→red, using the
  semantic tokens; add a `▲/▼` arrow on abnormal values.
- **Provenance + freshness.** Always show *who/what* produced an AI recommendation
  and *when* (`Recommended by ClinicalAgent (gpt-5.4) · 8 Jul 2026`) and the source
  data date (`Reported 5 Jul 2026`). Trust + audit.
- **Consequence microcopy.** Under the action, say what it will do
  ("Approve → activates the Rx in VetChart & notifies the owner").
- **Adaptive states.** If the payload can represent "nothing to act on" (e.g. a
  **safety-gate** path with no prescription), the UI must adapt — swap the drug +
  Approve/Modify/Reject for a clear "No prescription — safety gate" panel and a
  single **Acknowledge** action. Match the UI to every branch of the flow.
- **Label deterministic evidence.** Mark computed numbers "computed · not
  model-generated" so reviewers trust them.

---

## 5. Verify visually — don't tweak blind

CSS bugs (broken flex, invisible buttons, low contrast) are invisible to `npm run
build`. Screenshot the running app and **look**:

```bash
npm run dev -- --host --port 5173     # keep running
# headless screenshot (Chrome or Edge), give React time to render:
"/c/Program Files/Google/Chrome/Application/chrome.exe" --headless=new --disable-gpu \
  --hide-scrollbars --window-size=1400,1500 --virtual-time-budget=5000 \
  --screenshot="shot.png" "http://localhost:5173/"
```

Then open `shot.png`. Iterate against pixels, not guesses. To exercise a specific
state (e.g. the safety-gate path, or an enabled button), temporarily flip the mock
payload, screenshot, then revert.

---

## 6. Accessibility checklist

- Semantic HTML (`<section>`, `<table>`, `<fieldset>`/`<legend>`, `<dl>`).
- Visible focus rings (`--ring`) on all interactive elements.
- Colour is never the *only* signal — pair it with text/arrows/labels.
- Disabled controls stay legible (don't rely on low opacity).
- Every input has a `<label>`; icon-only elements get `aria-label`.
